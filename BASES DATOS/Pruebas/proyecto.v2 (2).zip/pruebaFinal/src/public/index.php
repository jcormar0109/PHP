<?php
    phpinfo();
